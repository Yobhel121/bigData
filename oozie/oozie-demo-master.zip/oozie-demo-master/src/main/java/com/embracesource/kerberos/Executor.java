package com.embracesource.kerberos;

public interface Executor<T> {

	/**
	 * ִ�в���
	 * @return
	 * @throws Exception
	 */
	public T exec() throws Exception;
}
