package com.embracesource.oozie;

interface Monitor extends OozieEndpoint {
	
	
}
