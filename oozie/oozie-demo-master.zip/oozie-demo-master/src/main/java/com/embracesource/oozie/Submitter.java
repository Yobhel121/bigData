package com.embracesource.oozie;

interface Submitter extends OozieEndpoint {
	
	
}
