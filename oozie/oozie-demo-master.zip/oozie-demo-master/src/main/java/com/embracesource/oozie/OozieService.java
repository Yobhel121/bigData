package com.embracesource.oozie;

public class OozieService extends AbstractOozieService {
	
	
}
